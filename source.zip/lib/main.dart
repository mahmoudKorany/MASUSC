import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:masusc/home/cubit/cubit.dart';
import 'package:masusc/layout_screen/layout_screen.dart';
import 'package:masusc/login_screen/login_cubit/login_cubit.dart';
import 'package:masusc/login_screen/login_cubit/login_states.dart';
import 'package:masusc/sessions_screen/cubit/sessions_cubit.dart';
import 'package:masusc/shared/cache-helper/cache-helper.dart';
import 'package:masusc/shared/constants.dart';
import 'package:masusc/shared/dio/dio.dart';
import 'package:masusc/splash/splash.dart';
import 'firebase_options.dart';
import 'login_screen/login_screen/login.dart';
import 'on_boarding_screen/on_boarding_screen.dart';
Widget? startScreen;
Future<void> _initializeNotifications() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
  AndroidInitializationSettings('background');
  const InitializationSettings initializationSettings =
  InitializationSettings(android: initializationSettingsAndroid);
  await FlutterLocalNotificationsPlugin().initialize(initializationSettings);
}
 Future<void> main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await CacheHelper.init();
  await DioHelper.init();
  await _initializeNotifications();
  bool? isOnBoardingDone = await CacheHelper.getData(key: 'onBoarding');
  uid = await CacheHelper.getData(key: 'userUid');
  if (isOnBoardingDone == null && uid == null) {
    startScreen = const StartScreen();
  } else if (isOnBoardingDone == true && uid == null) {
    startScreen = const LoginScreen();
  } else {
    startScreen = const LayoutScreen();
  }
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown
  ]);
  runApp(MyApp(startScreen: startScreen!));
}
class MyApp extends StatelessWidget {
  const MyApp({super.key, required this.startScreen});
  final Widget startScreen;
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (state) => LoginCubit()..getUserData(uid: uid),
        ),
        BlocProvider(
          create: (state) => LayOutCubit()..getBlogData(),
        ),
        BlocProvider(
          create: (state) => SessionsCubit()..getAllSessions(),
        ),
      ],
      child: BlocConsumer<LoginCubit,LoginStates>(
        listener: (context,state) {},
        builder:(context,state) => AnnotatedRegion<SystemUiOverlayStyle>(
          value: const SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
          ),
          child: ScreenUtilInit(
            designSize: const Size(393, 835),
            minTextAdapt: true,
            splitScreenMode: true,
            builder: (context, child) {
              return MaterialApp(
                theme: ThemeData(
                  disabledColor: Colors.black,
                ),
                builder: (context, child) {
                  return MediaQuery(
                    data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
                    child: child!,
                  );
                },
                debugShowCheckedModeBanner: false,
                home: const Splash(),
              );
            },
          ),
        ),
      ),
    );
  }
}