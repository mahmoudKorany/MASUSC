package com.example.masusc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
